#!/bin/bash
logger "Centralized Log Test"
